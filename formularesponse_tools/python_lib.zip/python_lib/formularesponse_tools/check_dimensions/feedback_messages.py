DEFAULT_MESSAGES = {
    'correct': 'dims OK...',
    'incorrect': 'dims NOT OK...',
    'add_error': 'ADDITION ERROR...',
    'arg_error': 'ARGUMENT ERROR...{func}', #may contain key {func}
    'pow_error': 'POWER ERROR...',
    'indeterminate': 'INDETERMINATE DIMS...',
    'dims': "\n<br/>\nSubmission dimensions: {dims}" #may contain key {dims}
}